abstract class BannerServiceInterface{
  Future<dynamic> getList();

}