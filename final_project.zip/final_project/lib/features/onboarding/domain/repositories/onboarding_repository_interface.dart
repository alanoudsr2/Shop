import 'package:p_shop_ecommerce/interface/repo_interface.dart';

abstract class OnBoardingRepositoryInterface<T> extends RepositoryInterface {}
