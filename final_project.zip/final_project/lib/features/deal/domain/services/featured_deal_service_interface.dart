abstract class FeaturedDealServiceInterface{
  Future<dynamic> getFeaturedDeal();
}