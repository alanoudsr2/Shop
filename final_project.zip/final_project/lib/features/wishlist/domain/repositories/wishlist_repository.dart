import 'package:p_shop_ecommerce/data/datasource/remote/dio/dio_client.dart';
import 'package:p_shop_ecommerce/data/datasource/remote/exception/api_error_handler.dart';
import 'package:p_shop_ecommerce/data/model/api_response.dart';
import 'package:p_shop_ecommerce/features/wishlist/domain/repositories/wishlist_repository_interface.dart';
import 'package:p_shop_ecommerce/utill/app_constants.dart';

class WishListRepository implements WishListRepositoryInterface {
  final DioClient? dioClient;

  WishListRepository({required this.dioClient});

  @override
  Future<ApiResponse> getList({int? offset = 1}) async {
    try {
      final response = await dioClient!.get(AppConstants.getWishListUri);
      return ApiResponse.withSuccess(response);
    } catch (e) {
      return ApiResponse.withError(ApiErrorHandler.getMessage(e));
    }
  }

  @override
  Future<ApiResponse> add(int productID) async {
    try {
      final response = await dioClient!
          .post(AppConstants.addWishListUri + productID.toString());
      return ApiResponse.withSuccess(response);
    } catch (e) {
      return ApiResponse.withError(ApiErrorHandler.getMessage(e));
    }
  }

  @override
  Future<ApiResponse> delete(int productID) async {
    try {
      final response = await dioClient!
          .delete(AppConstants.removeWishListUri + productID.toString());
      return ApiResponse.withSuccess(response);
    } catch (e) {
      return ApiResponse.withError(ApiErrorHandler.getMessage(e));
    }
  }

  @override
  Future get(String id) {
    // TODO: implement get
    throw UnimplementedError();
  }

  @override
  Future update(Map<String, dynamic> body, int id) {
    // TODO: implement update
    throw UnimplementedError();
  }
}
