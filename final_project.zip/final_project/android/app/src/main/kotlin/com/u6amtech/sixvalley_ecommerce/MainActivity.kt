package com.samie.p_shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
